﻿using System;

namespace Alejandro_Blanco_1142821
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Asigne el valor de r");
            double pi = 3.1416;
            double r = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine(r);
            Console.WriteLine(pi);
            Console.ReadKey();

        }
    }
}
